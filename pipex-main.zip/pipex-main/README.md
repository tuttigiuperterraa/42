Controllare:
============

#### 1- Nel bonus è sbagliato che pipex gestisca anche solo una pipe?
#### 2- Con here_doc pipex può gestire una sola pipe?

