Conrollare:
----------------
1- funzione check_input. Perche l'ho tolta?
