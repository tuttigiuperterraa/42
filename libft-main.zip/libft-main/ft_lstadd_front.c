#include "libft.h"

void ft_lstadd_front(t_list **lst, t_list *new)
{
  node -> next = *lst;
  *lst = new;
}
